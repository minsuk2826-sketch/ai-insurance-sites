window.LANDING_CONFIG = {
  // Supabase > Project Settings > API Keys의 publishable 또는 anon 공개 키만 입력하세요.
  // service_role/secret 키는 절대 입력하지 마세요.
  supabaseAnonKey: '여기에_공개키_입력',
  kakaoUrl: ''
};
