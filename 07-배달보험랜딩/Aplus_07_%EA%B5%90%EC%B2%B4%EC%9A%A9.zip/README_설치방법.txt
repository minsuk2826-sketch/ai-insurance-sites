A+에셋 랜딩페이지 (GitHub 07-배달보험랜딩 교체용)

1. 기존 07-배달보험랜딩 폴더 파일을 백업한 뒤 삭제합니다.
2. 이 ZIP 안의 파일 8개를 폴더 최상위에 업로드합니다. ZIP 자체를 올리지 마세요.
3. config.js 파일의 supabaseAnonKey에 Supabase 공개 anon/publishable 키를 입력합니다. secret/service_role 키 금지.
4. 카카오톡 URL이 있다면 kakaoUrl에 입력합니다.
5. Supabase customers 테이블에 name,phone,age_group,region,source,status 컬럼이 있는지 확인하고 RLS 정책이 유효한지 확인합니다.
6. 실제 개인정보 접수 전 개인정보 처리 주체·보유 기간을 안내문에 정확히 기재하세요.
7. 실제 신청 1건을 테스트하고 CRM에 저장되는지 확인하세요.

주의: 공개 INSERT 권한은 스팸/오남용 위험이 있습니다. 운영 시 rate limiting, CAPTCHA, 서버측 검증을 권장합니다.
현재 Supabase 공개 키가 없어 자동 접수는 아직 미연결 상태입니다.
